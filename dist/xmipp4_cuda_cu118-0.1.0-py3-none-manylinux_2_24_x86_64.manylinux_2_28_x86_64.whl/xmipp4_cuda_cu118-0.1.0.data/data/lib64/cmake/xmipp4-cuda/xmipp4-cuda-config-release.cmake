#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xmipp4-cuda" for configuration "Release"
set_property(TARGET xmipp4-cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xmipp4-cuda PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/xmipp4-plugins/libxmipp4-cuda.so"
  IMPORTED_SONAME_RELEASE "libxmipp4-cuda.so"
  )

list(APPEND _cmake_import_check_targets xmipp4-cuda )
list(APPEND _cmake_import_check_files_for_xmipp4-cuda "${_IMPORT_PREFIX}/lib/xmipp4-plugins/libxmipp4-cuda.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
